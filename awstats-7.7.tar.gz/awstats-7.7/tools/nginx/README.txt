This directory contains samples files to setup a NGinx server to
use AWStats with.